# Working Process

1. **Startup:** Arduino initializes the LCD, buttons, buzzer, indicator, fingerprint sensor and RTC.
2. **Fingerprint enrollment:** Operator selects an ID, places the same finger twice, and the sensor stores its template.
3. **Fingerprint matching:** User places a finger; the sensor searches its stored templates and returns a matching ID.
4. **Attendance recording:** Arduino reads date/time from the RTC and stores the values in EEPROM for the matched ID.
5. **Display:** LCD shows time/date and attendance status.
6. **Deletion:** Operator selects a fingerprint ID and asks the sensor to delete its template.
7. **Export:** The supplied code prints stored attendance records to the Serial Monitor.

This describes the behavior intended by the supplied sketch. Confirm each step during hardware testing.
