# Contribution and Commit Guide

Suggested meaningful commits:

1. `Initial commit: add supplied Arduino sketch and project documentation`
2. `Add project components and working process`
3. `Document pin conflicts and EEPROM layout issues`
4. `Add system block diagram`
5. `Add Colab code walkthrough notebook`
6. `Fix firmware pin assignments and EEPROM layout`
7. `Add verified compile and hardware test results`
8. `Add original hardware photographs`

Only commit genuine test results and photos of your own hardware. When changing pin assignments, update both firmware and pin documentation in the same commit.
