# Fingerprint-Based Attendance System

An Arduino-based fingerprint attendance project using a fingerprint sensor, RTC module, 16x2 LCD, push buttons, buzzer, indicator LED and EEPROM.

> **Status: Documentation and source organization completed; hardware verification pending.** The code is the supplied Arduino sketch, preserved for review. It must be corrected and tested with the exact board and modules before this can be described as a working hardware system.

## Features represented in the supplied code

- Fingerprint enrollment for IDs 1–10
- Fingerprint matching and ID detection
- Date and time display using a DS1307 RTC
- Attendance date/time storage in EEPROM
- LCD messages and buzzer/indicator feedback
- Fingerprint deletion
- Attendance export through the Serial Monitor

## Repository contents

```text
Fingerprint-Based-Attendance-System/
├── README.md
├── Code/
│   └── Fingerprint_Attendance_System_Original.ino
├── Notebook/
│   └── Fingerprint_Attendance_System_Explained.ipynb
├── Circuit-Diagram/
│   └── system-block-diagram.svg
├── Images/
│   └── .gitkeep
└── Documentation/
    ├── Components.md
    ├── Working_Process.md
    ├── Testing_Plan.md
    ├── Pin_Connections_and_Issues.md
    ├── Original_Code_Notes.md
    └── Contribution_Guide.md
```

## Hardware components mentioned or implied

- Arduino board (exact model must be confirmed)
- UART fingerprint sensor supported by Adafruit Fingerprint library
- 16x2 parallel LCD
- DS1307 RTC module
- Push buttons
- Buzzer
- Indicator LED and suitable resistor
- Jumper wires, breadboard and regulated power supply

## Software libraries

- Adafruit Fingerprint Sensor Library
- RTClib by Adafruit
- LiquidCrystal
- SoftwareSerial
- Wire
- EEPROM

## How to open the project

### Google Colab
Upload `Notebook/Fingerprint_Attendance_System_Explained.ipynb` to Google Colab. It is a code-reading notebook. Arduino C++ cells are not Python cells and are not executed by Colab's Python runtime.

### Arduino IDE
Open the `.ino` file from `Code/` in Arduino IDE, install the required libraries, select the correct board and port, then compile. Do not connect hardware until the pin conflicts, EEPROM layout, RTC startup behavior and record bounds described in `Documentation/Original_Code_Notes.md` are fixed.

## Project documentation

- `Documentation/Components.md` — component list and purpose
- `Documentation/Working_Process.md` — enrollment and attendance workflow
- `Documentation/Testing_Plan.md` — tests to perform and fill in with real results
- `Documentation/Pin_Connections_and_Issues.md` — known pin and memory concerns
- `Circuit-Diagram/system-block-diagram.svg` — high-level system architecture

## Important

No real hardware photographs or test results were supplied. Add your own circuit photos and actual test outcomes after building and testing the project. Do not present proposed wiring or unperformed tests as verified results.
