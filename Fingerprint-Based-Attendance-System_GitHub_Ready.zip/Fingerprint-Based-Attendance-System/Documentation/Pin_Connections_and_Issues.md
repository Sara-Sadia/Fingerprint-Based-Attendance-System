# Pin Connections and Known Wiring Issues

The submitted source currently defines:

| Function | Pin in supplied code |
|---|---:|
| LCD RS, EN, D4, D5, D6, D7 | 7, 6, 10, 11, 12, 13 |
| Fingerprint SoftwareSerial RX/TX | 2, 3 |
| Enroll | 14 |
| Delete | 15 |
| Up | 16 |
| Down | 17 |
| Match | 5 |
| Indicator LED | 7 |
| Buzzer | 5 |

## Conflicts
- LCD and indicator LED both use pin 7.
- Match button and buzzer both use pin 5.
- A final wiring diagram must not be treated as valid until the firmware pin definitions and actual wiring are updated together.

## RTC
For an Arduino Mega, I2C is normally SDA=20 and SCL=21. For an Uno, SDA=A4 and SCL=A5. Confirm the selected board.

## Electrical safety
- Check the exact fingerprint sensor supply voltage and UART logic levels.
- Connect all module grounds together.
- Do not drive a high-current buzzer directly from a GPIO pin; use a suitable transistor driver if required.
- Use a resistor in series with the indicator LED.
- Disconnect power before changing wiring.
