#include<EEPROM.h>
#include<LiquidCrystal.h>
LiquidCrystal lcd(7,6,10,11,12,13);
#include <SoftwareSerial.h>
SoftwareSerial fingerPrint(2, 3);
#include <Wire.h>
#include "RTClib.h"
RTC_DS1307 rtc;
#include "Adafruit_Fingerprint.h"

uint8_t id;
Adafruit_Fingerprint finger = Adafruit_Fingerprint(&fingerPrint);

#define enroll 14
#define del 15
#define up 16
#define down 17
#define match 5
#define indFinger 7
#define buzzer 5

#define records 10 // Updated to 10 users

// User attendance count variables
int user1,user2,user3,user4,user5,user6,user7,user8,user9,user10;

DateTime now;

void setup()
{
    delay(1000);
    lcd.begin(16,2);
    Serial.begin(9600);
    pinMode(enroll, INPUT_PULLUP);
    pinMode(up, INPUT_PULLUP);
    pinMode(down, INPUT_PULLUP);
    pinMode(del, INPUT_PULLUP);
    pinMode(match, INPUT_PULLUP);
    pinMode(buzzer, OUTPUT);
    pinMode(indFinger, OUTPUT);
    digitalWrite(buzzer, LOW);

    if(digitalRead(enroll) == 0)
    {
      digitalWrite(buzzer, HIGH);
      delay(300);
      digitalWrite(buzzer, LOW);
      lcd.clear();
      lcd.print("Please wait");
      lcd.setCursor(0,1);
      lcd.print("Downloading Data");
      Serial.println("Please wait");
      Serial.println("Downloading Data..");
      Serial.println();
      Serial.print("S.No. ");
      for(int i=0;i<records;i++)
      {
              digitalWrite(buzzer, HIGH);
              delay(300);
              digitalWrite(buzzer, LOW);
        Serial.print(" User ID");
        Serial.print(i+1);
        Serial.print(" ");
      }
      Serial.println();
      int eepIndex=0;
      for(int i=0;i<30;i++)
      {
        if(i+1<10)
        Serial.print('0');
        Serial.print(i+1);
        Serial.print(" ");
        eepIndex=(i*7);
        download(eepIndex);
        eepIndex=(i*7)+210;
        download(eepIndex);
        eepIndex=(i*7)+420;
        download(eepIndex);
        eepIndex=(i*7)+630;
        download(eepIndex);
        eepIndex=(i*7)+840;
        download(eepIndex);
        eepIndex=(i*7)+1050;
        download(eepIndex);
        eepIndex=(i*7)+1260;
        download(eepIndex);
        eepIndex=(i*7)+1470;
        download(eepIndex);
        eepIndex=(i*7)+1680;
        download(eepIndex);
        eepIndex=(i*7)+1890;
        download(eepIndex);
        Serial.println();
      }
    }

    if(digitalRead(del) == 0)
{
  lcd.clear();
  lcd.print("Hold to Reset");
  lcd.setCursor(0,1);
  lcd.print("3 Sec...");

  int holdTime = 0;

  // Require button hold for 3 seconds
  while(digitalRead(del) == 0)
  {
    delay(100);
    holdTime++;
    if(holdTime >= 30) break; // ~3 seconds
  }

  if(holdTime >= 30)
  {
    lcd.clear();
    lcd.print("Confirm Reset?");
    lcd.setCursor(0,1);
    lcd.print("UP=Yes DN=No");

    while(1)
    {
      if(digitalRead(up) == 0)
      {
        lcd.clear();
        lcd.print("Resetting.....");

        for(int i=1000;i<1000+records;i++)
          EEPROM.write(i,0);

        for(int i=0;i<(records*210);i++)
          EEPROM.write(i, 0xff);

        // Reset user variables
        user1=user2=user3=user4=user5=user6=user7=user8=user9=user10=0;

        lcd.clear();
        lcd.print("System Reset");
        lcd.setCursor(0,1);
        lcd.print("Successful");
        delay(1500);
        break;
      }

      else if(digitalRead(down) == 0)
      {
        lcd.clear();
        lcd.print("Reset Cancelled");
        delay(1000);
        break;
      }
    }
  }
  else
  {
    lcd.clear();
    lcd.print("Reset Cancelled");
    delay(1000);
  }
}

    lcd.clear();
    lcd.print(" Attendance ");
    lcd.setCursor(0,1);
    lcd.print(" System ");
    delay(2000);
    lcd.clear();
    lcd.print("POWERED BY");
    lcd.setCursor(0,1);
    lcd.print(" BUBT ");
    delay(2000);

    digitalWrite(buzzer, HIGH);
    delay(300);
    digitalWrite(buzzer, LOW);

    for(int i=1000;i<1000+records;i++)
    {
      if(EEPROM.read(i) == 0xff)
          EEPROM.write(i,0);
    }

    finger.begin(57600);
    Serial.begin(9600);
    lcd.clear();
    lcd.print("Finding Module");
    lcd.setCursor(0,1);
    delay(1000);
    if (finger.verifyPassword())
    {
      Serial.println("Found fingerprint sensor!");
      lcd.clear();
      lcd.print("Found Module ");
      delay(1000);
    }
    else
    {
      Serial.println("Did not find fingerprint sensor :(");
      lcd.clear();
      lcd.print("Module not Found");
      lcd.setCursor(0,1);
      lcd.print("Check Connections");
      while (1);
    }

    if (! rtc.begin())
       Serial.println("Couldn't find RTC");

    // Set RTC to compile time on every restart (comment out after initial set)
    rtc.adjust(DateTime(F(__DATE__), F(__TIME__)));

    if (! rtc.isrunning())
    {
      Serial.println("RTC is NOT running!");
    }

    lcd.setCursor(0,0);
    lcd.print("Press Match to ");
    lcd.setCursor(0,1);
    lcd.print("Start System");
    delay(2000);

    // Load the attendance counts for each user from EEPROM
    user1=EEPROM.read(1000);
    user2=EEPROM.read(1001);
    user3=EEPROM.read(1002); 
    user4=EEPROM.read(1003);
    user5=EEPROM.read(1004);
    user6=EEPROM.read(1005);
    user7=EEPROM.read(1006);
    user8=EEPROM.read(1007);
    user9=EEPROM.read(1008);
    user10=EEPROM.read(1009);

    lcd.clear();
    digitalWrite(indFinger, HIGH);
}

void loop()
{
    now = rtc.now();
    lcd.setCursor(0,0);
    lcd.print("Time->");
    if(now.hour()<10) lcd.print('0');
    lcd.print(now.hour(), DEC);
    lcd.print(':');
    if(now.minute()<10) lcd.print('0');
    lcd.print(now.minute(), DEC);
    lcd.print(':');
    if(now.second()<10) lcd.print('0');
    lcd.print(now.second(), DEC);
    lcd.print(" ");
    lcd.setCursor(0,1);
    lcd.print("Date->");
    if(now.day()<10) lcd.print('0');
    lcd.print(now.day(), DEC);
    lcd.print('/');
    if(now.month()<10) lcd.print('0');
    lcd.print(now.month(), DEC);
    lcd.print('/');
    lcd.print(now.year(), DEC);
    lcd.print(" ");
    delay(500);
    int result=getFingerprintIDez();
    if(result>0)
    {
              digitalWrite(indFinger, LOW);
              digitalWrite(buzzer, HIGH);
              delay(100);
              digitalWrite(buzzer, LOW);
              lcd.clear();
              lcd.print("ID:");
              lcd.print(result);
              lcd.setCursor(0,1);
              lcd.print("Please Wait....");
              delay(1000);
              attendance(result);
              lcd.clear();
              lcd.print("Attendance");
              lcd.setCursor(0,1);
              lcd.print("Registered");
              delay(1500);

              // Show attendance time
              lcd.clear();
              lcd.print("Time:");
              if(now.hour()<10) lcd.print('0');
              lcd.print(now.hour());
              lcd.print(':');
              if(now.minute()<10) lcd.print('0');
              lcd.print(now.minute());
              lcd.print(':');
              if(now.second()<10) lcd.print('0');
              lcd.print(now.second());
              lcd.setCursor(0,1);
              lcd.print("Date:");
              if(now.day()<10) lcd.print('0');
              lcd.print(now.day());
              lcd.print('/');
              if(now.month()<10) lcd.print('0');
              lcd.print(now.month());
              lcd.print('/');
              lcd.print(now.year());

              delay(2000);

              digitalWrite(indFinger, HIGH);
              return;
    }
    checkKeys();
    delay(300);
}

// dmyyhms - 7 bytes
void attendance(int id)
{
  int user=0,eepLoc=0;
  switch(id)
  {
    case 1: eepLoc=0; user=user1++; break;
    case 2: eepLoc=210; user=user2++; break;
    case 3: eepLoc=420; user=user3++; break;
    case 4: eepLoc=630; user=user4++; break;
    case 5: eepLoc=840; user=user5++; break;
    case 6: eepLoc=1050; user=user6++; break;
    case 7: eepLoc=1260; user=user7++; break;
    case 8: eepLoc=1470; user=user8++; break;
    case 9: eepLoc=1680; user=user9++; break;
    case 10:eepLoc=1890; user=user10++; break;
    default: return; // user id not handled
  }
  int eepIndex=(user*7)+eepLoc;
  EEPROM.write(eepIndex++, now.hour());
  EEPROM.write(eepIndex++, now.minute());
  EEPROM.write(eepIndex++, now.second());
  EEPROM.write(eepIndex++, now.day());
  EEPROM.write(eepIndex++, now.month());
  EEPROM.write(eepIndex++, now.year() >> 8);
  EEPROM.write(eepIndex++, now.year());

  // update user counts in EEPROM
  EEPROM.write(1000, user1);
  EEPROM.write(1001, user2);
  EEPROM.write(1002, user3);
  EEPROM.write(1003, user4);
  EEPROM.write(1004, user5);
  EEPROM.write(1005, user6);
  EEPROM.write(1006, user7);
  EEPROM.write(1007, user8);
  EEPROM.write(1008, user9);
  EEPROM.write(1009, user10);
}

void checkKeys()
{
   if(digitalRead(enroll) == 0)
   {
    lcd.clear();
    lcd.print("Please Wait");
    delay(1000);
    while(digitalRead(enroll) == 0);
    Enroll();
   }
   else if(digitalRead(del) == 0)
   {
    lcd.clear();
    lcd.print("Please Wait");
    delay(1000);
    while(digitalRead(del) == 0);
    delet();
   }
}

void Enroll()
{
   int count=1;
   lcd.clear();
   lcd.print("Enter Finger ID:");
   while(1)
   {
    lcd.setCursor(0,1);
     lcd.print(count);
     if(digitalRead(up) == 0)
     {
       count++;
       if(count>records)
       count=1;
       delay(500);
     }
     else if(digitalRead(down) == 0)
     {
       count--;
       if(count<1)
       count=records;
       delay(500);
     }
     else if(digitalRead(del) == 0)
     {
          id=count;
          getFingerprintEnroll();
          for(int i=0;i<records;i++)
          {
            if(EEPROM.read(i) == 0xff)
            {
              EEPROM.write(i, id);
              break;
            }
          }
          return;
     }
       else if(digitalRead(enroll) == 0)
     {
          return;
     }
 }
}

void delet()
{
   int count=1;
   lcd.clear();
   lcd.print("Enter Finger ID");
   while(1)
   {
    lcd.setCursor(0,1);
     lcd.print(count);
     if(digitalRead(up) == 0)
     {
       count++;
       if(count>records)
       count=1;
       delay(500);
     }
     else if(digitalRead(down) == 0)
     {
       count--;
       if(count<1)
       count=records;
       delay(500);
     }
     else if(digitalRead(del) == 0)
     {
          id=count;
          deleteFingerprint(id);
          // Clear the fingerprint record from EEPROM
          for(int i=0; i<records; i++)
          {
              if(EEPROM.read(i) == id)
              {
                  EEPROM.write(i, 0xff); // Mark as deleted
                  break;
              }
          }
          // Reset attendance count for the user
          switch(id)
          {
              case 1: user1 = 0; break;
              case 2: user2 = 0; break;
              case 3: user3 = 0; break;
              case 4: user4 = 0; break;
              case 5: user5 = 0; break;
              case 6: user6 = 0; break;
              case 7: user7 = 0; break;
              case 8: user8 = 0; break;
              case 9: user9 = 0; break;
              case 10: user10 = 0; break;
          }
          // Update the EEPROM with the reset counts
          EEPROM.write(1000, user1);
          EEPROM.write(1001, user2);
          EEPROM.write(1002, user3);
          EEPROM.write(1003, user4);
          EEPROM.write(1004, user5);
          EEPROM.write(1005, user6);
          EEPROM.write(1006, user7);
          EEPROM.write(1007, user8);
          EEPROM.write(1008, user9);
          EEPROM.write(1009, user10);
          return;
     }
       else if(digitalRead(enroll) == 0)
     {
          return;
     }
 }
}

uint8_t getFingerprintEnroll()
{
  int p = -1;
  lcd.clear();
  lcd.print("finger ID:");
  lcd.print(id);
  lcd.setCursor(0,1);
  lcd.print("Place Finger");
  delay(2000);
  while (p != FINGERPRINT_OK)
  {
    p = finger.getImage();
    switch (p)
    {
    case FINGERPRINT_OK:
      Serial.println("Image taken");
      lcd.clear();
      lcd.print("Image taken");
      break;
    case FINGERPRINT_NOFINGER:
      Serial.println("No Finger");
      lcd.clear();
      lcd.print("No Finger");
      break;
    case FINGERPRINT_PACKETRECIEVEERR:
      Serial.println("Communication error");
      lcd.clear();
      lcd.print("Comm Error");
      break;
    case FINGERPRINT_IMAGEFAIL:
      Serial.println("Imaging error");
      lcd.clear();
      lcd.print("Imaging Error");
      break;
    default:
      Serial.println("Unknown error");
       lcd.clear();
      lcd.print("Unknown Error");
      break;
    }
  }
  // OK success!
  p = finger.image2Tz(1);
  switch (p) {
    case FINGERPRINT_OK:
      Serial.println("Image converted");
      lcd.clear();
      lcd.print("Image converted");
      break;
    case FINGERPRINT_IMAGEMESS:
      Serial.println("Image too messy");
       lcd.clear();
       lcd.print("Image too messy");
      return p;
    case FINGERPRINT_PACKETRECIEVEERR:
      Serial.println("Communication error");
            lcd.clear();
      lcd.print("Comm Error");
      return p;
    case FINGERPRINT_FEATUREFAIL:
      Serial.println("Could not find fingerprint features");
            lcd.clear();
      lcd.print("Feature Not Found");
      return p;
    case FINGERPRINT_INVALIDIMAGE:
      Serial.println("Could not find fingerprint features");
                  lcd.clear();
      lcd.print("Feature Not Found");
      return p;
    default:
      Serial.println("Unknown error");
                  lcd.clear();
      lcd.print("Unknown Error");
      return p;
  }
  Serial.println("Remove finger");
  lcd.clear();
  lcd.print("Remove Finger");
  delay(2000);
  p = 0;
  while (p != FINGERPRINT_NOFINGER) {
    p = finger.getImage();
  }
  Serial.print("ID "); Serial.println(id);
  p = -1;
  Serial.println("Place same finger again");
   lcd.clear();
      lcd.print("Place Finger");
      lcd.setCursor(0,1);
      lcd.print(" Again");
  while (p != FINGERPRINT_OK) {
    p = finger.getImage();
    switch (p) {
    case FINGERPRINT_OK:
      Serial.println("Image taken");
      break;
    case FINGERPRINT_NOFINGER:
      Serial.print(".");
      break;
    case FINGERPRINT_PACKETRECIEVEERR:
      Serial.println("Communication error");
      break;
    case FINGERPRINT_IMAGEFAIL:
      Serial.println("Imaging error");
      break;
    default:
      Serial.println("Unknown error");
      return;
    }
  }
  // OK success!
  p = finger.image2Tz(2);
  switch (p) {
    case FINGERPRINT_OK:
      Serial.println("Image converted");
      break;
    case FINGERPRINT_IMAGEMESS:
      Serial.println("Image too messy");
      return p;
    case FINGERPRINT_PACKETRECIEVEERR:
      Serial.println("Communication error");
      return p;
    case FINGERPRINT_FEATUREFAIL:
      Serial.println("Could not find fingerprint features");
      return p;
    case FINGERPRINT_INVALIDIMAGE:
      Serial.println("Could not find fingerprint features");
      return p;
    default:
      Serial.println("Unknown error");
      return p;
  }
  // OK converted!
  Serial.print("Creating model for #"); Serial.println(id);
  p = finger.createModel();
  if (p == FINGERPRINT_OK) {
    Serial.println("Prints matched!");
  } else if (p == FINGERPRINT_PACKETRECIEVEERR) {
    Serial.println("Communication error");
    return p;
  } else if (p == FINGERPRINT_ENROLLMISMATCH) {
    Serial.println("Fingerprints did not match");
    return p;
  } else {
    Serial.println("Unknown error");
    return p;
  }
  Serial.print("ID "); Serial.println(id);
  p = finger.storeModel(id);
  if (p == FINGERPRINT_OK) {
    Serial.println("Stored!");
    lcd.clear();
    lcd.print("Stored!");
    delay(2000);
  } else if (p == FINGERPRINT_PACKETRECIEVEERR) {
    Serial.println("Communication error");
    return p;
  } else if (p == FINGERPRINT_BADLOCATION) {
    Serial.println("Could not store in that location");
    return p;
  } else if (p == FINGERPRINT_FLASHERR) {
    Serial.println("Error writing to flash");
    return p;
  }
  else {
    Serial.println("Unknown error");
    return p;
  }
}

int getFingerprintIDez()
{
  uint8_t p = finger.getImage();
  if (p != FINGERPRINT_OK)
  return -1;
  p = finger.image2Tz();
  if (p != FINGERPRINT_OK)
  return -1;
  p = finger.fingerFastSearch();
  if (p != FINGERPRINT_OK)
  {
   lcd.clear();
   lcd.print("Finger Not Found");
   lcd.setCursor(0,1);
   lcd.print("Try Later");
   delay(2000);
  return -1;
  }
  // found a match!
  Serial.print("Found ID #");
  Serial.print(finger.fingerID);
  return finger.fingerID;
}

uint8_t deleteFingerprint(uint8_t id)
{
  uint8_t p = -1;
  lcd.clear();
  lcd.print("Please wait");
  p = finger.deleteModel(id);
  if (p == FINGERPRINT_OK)
  {
    Serial.println("Deleted!");
    lcd.clear();
    lcd.print("Finger Deleted");
    lcd.setCursor(0,1);
    lcd.print("Successfully");
    delay(1000);
  }
  else
  {
    Serial.print("Something Wrong");
    lcd.clear();
    lcd.print("Something Wrong");
    lcd.setCursor(0,1);
    lcd.print("Try Again Later");
    delay(2000);
    return p;
  }
  return p;
}

void download(int eepIndex)
{
            if(EEPROM.read(eepIndex) != 0xff)
            {
              Serial.print("T->");
              if(EEPROM.read(eepIndex)<10)
              Serial.print('0');
              Serial.print(EEPROM.read(eepIndex++));
              Serial.print(':');  
              if(EEPROM.read(eepIndex)<10)
              Serial.print('0');
              Serial.print(EEPROM.read(eepIndex++));
              Serial.print(':'); 
              if(EEPROM.read(eepIndex)<10)
              Serial.print('0');
              Serial.print(EEPROM.read(eepIndex++));
              Serial.print(" D->");
              if(EEPROM.read(eepIndex)<10)
              Serial.print('0');
              Serial.print(EEPROM.read(eepIndex++));
              Serial.print('/');
              if(EEPROM.read(eepIndex)<10)
              Serial.print('0');           
              Serial.print(EEPROM.read(eepIndex++));
              Serial.print('/');            
              Serial.print(EEPROM.read(eepIndex++)<<8 | EEPROM.read(eepIndex++));
            }
            else
            {
               Serial.print("---------------------------");
            }
            Serial.print(" ");
}
