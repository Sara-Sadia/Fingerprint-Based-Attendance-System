# Review of the submitted Arduino sketch

The source file in `Code/` is the code supplied for this project, preserved as a reference. It contains the main firmware functions for fingerprint enrollment, matching, attendance storage, LCD output, RTC date/time, EEPROM, and Serial Monitor export.

## Issues that must be resolved before claiming a working build

1. **Pin collision:** LCD uses digital pin 7 and `indFinger` also uses pin 7.
2. **Pin collision:** `match` and `buzzer` are both assigned digital pin 5.
3. **EEPROM capacity:** 10 users × 30 attendance records × 7 bytes = 2,100 bytes, before counters. This does not fit an Arduino Uno/Nano ATmega328P EEPROM (1,024 bytes). A Mega 2560 has 4,096 bytes, but the current counter addresses 1,000–1,009 overlap the fifth user's attendance area (840–1,049).
4. **RTC behavior:** `rtc.adjust(DateTime(F(__DATE__), F(__TIME__)))` runs on every startup in the supplied code, resetting the RTC to compile time.
5. **Record bounds:** attendance logging does not stop after 30 entries per user, so it can write outside the allocated per-user block.
6. **Enrollment storage overlap:** EEPROM addresses 0–9 are used for fingerprint ID markers, but they are also part of the first user's attendance data.
7. **Match button:** a match button is defined and shown in the startup message, but the supplied `loop()` does not use it to start matching.
8. **Hardware verification:** exact sensor model, board model, wiring, power requirements, compile result, and physical test results were not supplied.

## Important project status

The repository is organized and documented, but the supplied firmware is not yet a verified working build. Fix the issues above, compile for the exact Arduino board, and complete the hardware test checklist before marking the project as fully operational.
