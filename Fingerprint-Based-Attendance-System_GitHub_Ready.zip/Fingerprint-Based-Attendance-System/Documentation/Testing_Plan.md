# Testing Plan

> **All results are pending.** Do not mark a test passed until it has actually been performed.

| Test | Procedure | Expected result | Actual result |
|---|---|---|---|
| Compile | Compile in Arduino IDE for the selected board | No compile errors | Not tested |
| LCD | Power on the assembled circuit | Startup/status text appears | Not tested |
| Fingerprint sensor | Start with sensor connected | Sensor is detected | Not tested |
| RTC | Start with RTC connected | Correct date/time is displayed | Not tested |
| Enrollment | Enroll a finger under an ID | Template is stored | Not tested |
| Matching | Scan an enrolled finger | Correct fingerprint ID is returned | Not tested |
| Attendance | Scan an enrolled finger | Date/time is saved | Not tested |
| Serial export | Trigger download mode and open Serial Monitor | Saved records are printed | Not tested |
| Deletion | Delete an enrolled ID | Template is removed | Not tested |
| Reset | Confirm reset using the buttons | Attendance storage is cleared | Not tested |

## Test session details
- Date:
- Board model:
- Fingerprint sensor model:
- RTC model:
- Arduino IDE version:
- Library versions:
- Tester:
- Notes:
