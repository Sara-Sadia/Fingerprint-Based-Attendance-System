# Components List

| Component | Quantity | Purpose | Confirmation needed |
|---|---:|---|---|
| Arduino board | 1 | Main controller | Exact model required |
| UART fingerprint sensor | 1 | Fingerprint enrollment and matching | Exact model, voltage and logic level |
| 16x2 LCD | 1 | Display date, time and messages | LCD type and contrast wiring |
| DS1307 RTC module | 1 | Real-time clock | Confirm module and battery |
| Push buttons | 4–5 | Enroll, delete, up, down and possibly match | Confirm final control design |
| Buzzer | 1 | Audible feedback | Check current; driver may be needed |
| LED | 1 | Status indication | Use a current-limiting resistor |
| Breadboard and jumper wires | As needed | Circuit assembly | — |
| Regulated power supply | 1 | Powers board and modules | Match module specifications |

## Software
Arduino IDE, Adafruit Fingerprint Sensor Library, RTClib, LiquidCrystal, SoftwareSerial, Wire and EEPROM.
